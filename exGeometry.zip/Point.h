/*
  File:        Point.h
  Objective:   Definition of class Point
*/

#ifndef POINT_H
#define POINT_H

#include <iostream>
using namespace std;

class Point {
private:
    float xc,yc;      // x-y coordinates
public:
    Point(float newx=0, float newy=0){ xc=newx; yc=newy; }
    float x() const       { return xc; }
    float x(float newx)   { return xc = newx; }
    float y() const       { return yc; }
    float y(float newy)   { return yc = newy; }
    Point operator+(const Point& p) const {
        return Point(xc+p.xc, yc+p.yc);
    }

    void operator+=(const Point& p) {
        xc += p.x();
        yc += p.y();
    }

    void printOn(ostream& strm=cout) const;

};

    ostream& operator<<(ostream& strm, const Point& p);

#endif
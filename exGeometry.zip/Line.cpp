/*
  File:        Line.cpp
  Objective:   Implementation of class Line
*/

#include "Line.h"

Line::Line(const Point a, const Point b)
: Shape(a), endp(b)
{ }

void Line::move(const Point d)
{
     Shape::move(d);
     endp += d;
}

void Line::draw() const
{
     cout << "Line from " << origin() << " to "
          << endp << endl;
}
/*
  File:         Geometry.cpp
  Objective:    Test of geometric class hierarchy
*/


#include <iostream>
#include "Point.h"
#include "Line.h"
#include "Circle.h"
#include "Picture.h"
#include "Triangle.h"

using std::cout;
using std::endl;

int main(int argc, char* argv[])
{
        Line li1(Point(10,20),Point(100,200));  // create a Line
        Circle c1(Point(100,200),100);          // create a Circle
        li1.draw();     // draw the line
        c1.draw();      // draw the circle

        Picture pic1;   // create a Picture
        pic1.add(li1);  // add the line to the picture
        pic1.add(c1);   // ..and the circle
        cout << "==>Picture 1:" << endl;
        pic1.draw(); cout << endl;      // draw the picture
        pic1.move(Point(-10,-5));  // move the picture
        cout << "==>Picture 1 moved (-10,-5):" << endl;
        pic1.draw(); cout << endl;      // draw the picture

        Triangle t1(Point(-10,0),Point(20,30),Point(40,60));
        Circle c2(Point(50,75),80);

        // define another picture
        Picture pic2;
        pic2.add(t1);   // add t1 to the picture
        pic2.add(c2);   // ...and c2
        cout << "==>Picture 2" << endl;
        pic2.draw();   cout << endl;   // draw
        pic2.move(Point(20,30));        // move the picture
        cout << "==>Picture 2 moved (20,30):" << endl;
        pic2.draw(); cout << endl;      // draw the picture

        cout << "--- Completed ----------------" << endl;

        return 0;
}

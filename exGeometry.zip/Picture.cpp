/*
  File:         Picture.cpp
  Objective:    Definition of class Picture
*/

#include "Picture.h"

void Picture::add(Shape &t)
{
    ++n;
    shapes.push_back(&t);   // add pointer to Shape to Picture
}

void Picture::draw() const  // draw a Picture
{
    for (int i=0; i<shapes.size(); i++)
        shapes[i]->draw();  // draw the objects
}


void Picture::move(const Point d)
{
    for (int i=0; i<n; i++)
        shapes[i]->move(d); // move every shape
}

//
// Created by Marcus Roos on 2020-09-08.
// Mittuniversitet
// StudentID: Maro1904
//

#include "MainMenu.h"

int main() {
    MainMenu mainmenu;
    mainmenu.run();
    return 0;
}

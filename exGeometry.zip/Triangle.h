/*
  File:         Triangle.h
  Objective:    Definition of class Triangle
*/

#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "Point.h"
#include "Shape.h"

class Triangle: public Shape {
private:
    Point p2,p3;    // 2nd and 3rd vertices
public:
    Triangle (const Point a, const Point b, const Point c);
    virtual ~Triangle() {}
    virtual void move(const Point d);
    virtual void draw() const;
};

#endif

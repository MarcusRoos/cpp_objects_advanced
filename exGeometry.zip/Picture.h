/*
  File:         Picture.h
  Objective:    Definition of class Picture
*/

#ifndef PICTURE_H
#define PICTURE_H

#include "Point.h"
#include "Shape.h"
#include <vector>

using std::vector;

class Picture {
private:
        vector<Shape*> shapes; // pointers to shapes
        int n;                 // number of shapes in this Picture
public:
        Picture( )
        :n(0) { }  // constructor

        virtual ~Picture(){}    // destructor
        void add(Shape&);       // add Shape to Picture
        void draw() const;      // draw picture;
        void move(const Point d);
};

#endif

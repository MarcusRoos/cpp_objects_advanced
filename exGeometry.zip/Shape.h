/*
  File:        Shape.h
  Objective:   Abstract base class for concrete shapes
*/


#ifndef SHAPE_H
#define SHAPE_H

#include "Point.h"

class Shape {
private:
    Point org;      // origin
protected:
    void setOrg(Point &no) { org=no;}

public:
     Shape() {}
     Shape(const Point o) : org(o) { }  //origin
     virtual ~Shape() {}
     Point origin() const { return org;}
     virtual void move(const Point d) { org+=d; }

     // draw is pure virtual ==>  Shape abstract class
     virtual void draw() const =0; // pure virtual
};

#endif
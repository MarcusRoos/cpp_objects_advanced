/*
  File:        Line.h
  Objective:   Definition of class Line
*/

#ifndef LINE_H
#define LINE_H


#include "Point.h"
#include "Shape.h"

class Line: public Shape {
private:
    Point endp;        // end point
public:
    Line(const Point a, const Point b);
    virtual ~Line() {}
    virtual void move(const Point d);
    virtual void draw() const;
};

#endif

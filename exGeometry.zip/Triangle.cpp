/*
  File:         Triangle.cpp
  Objective:    Implementation of class Triangle
*/

#include "Triangle.h"


Triangle::Triangle (const Point a, const Point b, const Point c)
: Shape(a), p2(b), p3(c)
{ }

void Triangle::move(const Point d)
{
    Shape::move(d);   // move origin and tp
    p2 += d;
    p3 += d;
}

void Triangle::draw() const
{
    cout << "Triangle with corners " << origin()
         << ", " << p2 << " and " << p3 << endl;
}
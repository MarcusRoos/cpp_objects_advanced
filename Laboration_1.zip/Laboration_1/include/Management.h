//
// Created by Marcus Roos on 2020-09-08.
// Mittuniversitet
// StudentID: Maro1904
//

#ifndef DT060G_MANAGEMENT_H
#define DT060G_MANAGEMENT_H

#include <string>
#include <vector>

void pauseFunction(const std::string& text);
std::string validate(std::string input);
/*
std::string validateFileName(std::string input);
std::string lowercase(std::string input);
*/
#endif

/*
  File:         Circle.cpp
  Objective:    Implementation of class Circle
*/

#include "Circle.h"

void Circle::draw() const
{
    cout << "Circle with center " << origin()
         << " and radius " << rad << endl;
}

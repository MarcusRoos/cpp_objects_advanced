/*
  File:         Circle.h
  Objective:    definition of class Circle
*/

#ifndef CIRCLE_H
#define CIRCLE_H

#include "Point.h"
#include "Shape.h"

class Circle: public Shape {
private:
     int rad;        // radius of circle
public:
     Circle(const Point c, int r) : Shape(c) { rad = r; }
     virtual ~Circle() {}
     virtual void draw() const;
};

#endif
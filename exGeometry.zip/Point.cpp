/*
  File:         Point.cpp
  Objective:    Implementation�of class Point
*/


#include "Point.h"

void Point::printOn(ostream& strm) const
{
    strm << '(' << xc << ',' << yc << ')';
}

ostream& operator<<(ostream& strm, const Point& p)
{
        p.printOn(strm);
        return strm;
}